﻿// vonKochView.cpp: 구현 파일
//

#include "pch.h"
#include "MFCApplication8.h"
#include "vonKochView.h"
#include "vonKoch.h"


// vonKochView

IMPLEMENT_DYNCREATE(vonKochView, CView)

vonKochView::vonKochView()
{

}

vonKochView::~vonKochView()
{
}

BEGIN_MESSAGE_MAP(vonKochView, CView)
END_MESSAGE_MAP()


// vonKochView 그리기

void vonKochView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: 여기에 그리기 코드를 추가합니다.

	// ASSERT_VALID(pDoc);

	vonKoch(200, 4, pDC).snowflake();
}


// vonKochView 진단

#ifdef _DEBUG
void vonKochView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void vonKochView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// vonKochView 메시지 처리기
